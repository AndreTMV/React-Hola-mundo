var miVariable = 'variable'
miVariable = 'otro valor'

let variable = 'variable creada con let'
//console.log(variable)
variable = 'otro valor a let'

const constante = 'este valor es constante'
//constante = 'esta operacion es invalida'
console.log(constante)

//console.log(miVariable, variable)
